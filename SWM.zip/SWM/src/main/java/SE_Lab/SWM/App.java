package SE_Lab.SWM;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println("Smart Waste Management System running..." );
    }
}
